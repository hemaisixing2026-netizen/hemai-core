---
name: system-metrics
description: 系统指标采集——性能优化
version: 1.0
---
# 系统指标
自动采集运行指标。静默运行。
